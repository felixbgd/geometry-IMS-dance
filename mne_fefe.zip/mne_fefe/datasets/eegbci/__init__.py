"""EEG Motor Movement/Imagery Dataset."""

from .eegbci import data_path, load_data, standardize
