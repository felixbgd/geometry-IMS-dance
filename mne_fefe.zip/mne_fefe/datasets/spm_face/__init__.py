"""SPM face dataset."""

from .spm_data import data_path, has_spm_data, get_version, requires_spm_data
