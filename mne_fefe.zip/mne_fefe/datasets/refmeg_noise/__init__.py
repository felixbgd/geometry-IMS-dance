"""MEG reference-noise data set."""

from .refmeg_noise import data_path, get_version
