"""Fake dataset for testing."""

from ._fake import data_path, get_version
