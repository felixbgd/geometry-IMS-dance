"""fieldtrip Cortico-Muscular Coherence (CMC) Dataset."""

from .fieldtrip_cmc import data_path, get_version
