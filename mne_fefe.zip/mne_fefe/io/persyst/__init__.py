"""Persyst module for conversion to FIF."""

# Author: Adam Li <adam2392@gmail.com>
#
# License: BSD-3-Clause

from .persyst import read_raw_persyst
