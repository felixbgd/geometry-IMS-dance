"""fNIRS module for conversion to FIF."""

# Author: Robert Luke <mail@robertluke.net>
#
# License: BSD-3-Clause

from .nirx import read_raw_nirx
