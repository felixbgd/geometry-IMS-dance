"""Module to convert user data to FIF."""

# Author: Eric Larson <larson.eric.d@gmail.com>

from .array import RawArray
