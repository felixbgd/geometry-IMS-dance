"""Reader for CURRY data."""

# Author: Dirk Gütlin <dirk.guetlin@stud.sbg.ac.at>
#
# License: BSD-3-Clause

from .curry import read_raw_curry
