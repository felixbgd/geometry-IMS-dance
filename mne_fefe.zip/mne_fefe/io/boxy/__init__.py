"""fNIRS module for conversion to FIF."""

# Authors: Kyle Mathewson, Jonathan Kuziek <kuziek@ualberta.ca>
#
# License: BSD-3-Clause

from .boxy import read_raw_boxy
