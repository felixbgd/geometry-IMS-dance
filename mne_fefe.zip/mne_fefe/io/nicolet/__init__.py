"""Nicolet module for conversion to FIF."""

# Author: Jaakko Leppakangas <jaeilepp@student.jyu.fi>
#
# License: BSD-3-Clause

from .nicolet import read_raw_nicolet
