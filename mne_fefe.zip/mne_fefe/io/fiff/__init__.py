"""FIF raw data reader."""

from .raw import Raw
from .raw import read_raw_fif
